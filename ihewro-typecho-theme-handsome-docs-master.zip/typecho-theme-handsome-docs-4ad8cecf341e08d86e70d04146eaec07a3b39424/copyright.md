1. 主题后台界面风格来自material主题
2. 主题function.php部分代码来自 qqdie设计的主题
3. 感谢 links插件作者 寒泥
4. 主题cross自定义模板代码来自 breeze主题by闪闪的星
5. 主题内置的播放器代码修改自youduBGM
6. 短代码css样式来自DNSHH主题
7. 主题基于 [Flatkit](https://themeforest.net/item/flatkit-app-ui-kit/13231484?s_rank=4) 框架 和[Angulr](https://themeforest.net/item/angulr-bootstrap-admin-web-app-with-angularjs/8437259?s_rank=7) 后台框架制作而成。
8. 主题多语言包功能核心代码来着hran的[mirages](https://hran.me/archives/mirages-intro.html)主题
9. 网易云音乐歌单展示页面由biji.io提供
10. 评论表情功能引用项目[owo](https://github.com/DIYgod/OwO)

感谢所有提出建设性建议的小伙伴们！
感谢本项目引用的项目作者的贡献！

如果遗漏申明或者版权问题，请及时联系作者，感谢！
