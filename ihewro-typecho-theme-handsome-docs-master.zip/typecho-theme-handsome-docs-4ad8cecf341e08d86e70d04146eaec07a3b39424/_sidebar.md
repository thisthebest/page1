- 开始使用
  - [快速开始](/start)
  - [更新主题](/update)
  - [授权平台](/auth)
  - <li ><a style="color:red" href="#/common-problem">常见问题</a></li>

- 特色功能
  - [从微信公众号发送时光机](/wechat)
  - [从浏览器扩展发送时光机](/crx)
  - [从微信公众号发送文章](/wechat_post)

- 进阶设定
  - [相册](/album)
  - [内容加密](/lock)
  - [RSS 配置](/rss)
  - [独立页面](/page)
  - [评论系统](/comment)
  - <li><a style="color:red" href="#/functions">增强功能</a></li>
  - [评论表情](/emotion)
  - [图标列表](/icons)
  - [速度优化](/speed)
  - [多语言设置](/i18n)
  - [自定义栏目](/customize)
  - [自定义pjax动画](/pjaxanimate)
  - [个性化修改](/customEdit)
  - [typecho相关](/typecho)
  - [布局配色指南](/color)

- 其他说明
  - [开发日志](/changelog)
  - [问题反馈](/feedback)
  - [版权声明](/copyright)


