你可以通过以下方式反馈问题：

* [邮件交流：ihewro#163.com](mailto:ihewro@163.com)
* [QQ:535425690](http://wpa.qq.com/msgrd?v=3&uin=535425690&site=qq&menu=yes)
* [购买主题，加入主题收费群](https://www.ihewro.com/archives/489/#主题售价)
