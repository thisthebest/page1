以下模块由勤劳的使用者提供的关于handsome主题的自定义修改内容，你可以应用到自己的主题中来。

!> 欢迎投稿，感谢！

<b> <a style="color:red" href="https://handsome.ihewro.com/user.html" target="_blank">handsome用户分享社区</a></b>

!> 用户可以在「handsome自助授权平台」中添加教程，可以添加任何你觉得不错的教程

* [本博客基于Handsome主题的一些小修改教程](https://www.moerats.com/archives/628/)

* [这篇文章主要是typecho下的彩色标签云实现方式](https://ixiyu.me/archives/typecho-colorful-tag.html)

* [一个追番列表独立页模板](https://imalan.cn/archives/88/)

* [把可爱的 Pio 捉到博客上吧！](https://imalan.cn/archives/95/)

* [Typecho 在主题与 EditorMD 前台解析冲突的情况下使用其样式](https://lolico.moe/modification/typecho-editormd-solution.html)

* [ColorHighlight插件实现Mac风格代码高亮](https://www.xcnte.com/archives/523/)

* [Typecho下实现一键评论打卡功能](https://www.xcnte.com/archives/527/)

* [安利一款Hansome主题专用的UserAgent插件](https://blog.xiaojian.party/coding/useragent-modify.html)

* [神代綺凜式魔改出现的相关问题解决附魔改教程](https://www.sukeycz.com/course/mod-jk)

* [handsome主题美化/修改教程](https://www.citrons.cn/jishu/211.html)

